--
-- PostgreSQL database dump
--

\restrict 7cfuFiRArzshAMdgoCTSmzJkSkyexOHaq82ZqnpbTYl8g3Bb1WfiYy0mKIv7UcB

-- Dumped from database version 17.2
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: AiGenerationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AiGenerationStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED'
);


--
-- Name: AiGenerationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AiGenerationType" AS ENUM (
    'PRODUCT',
    'BLOG',
    'SEO'
);


--
-- Name: BacklinkOpportunityType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BacklinkOpportunityType" AS ENUM (
    'FORUM',
    'BUSINESS_DIRECTORY',
    'INDUSTRY_DIRECTORY',
    'B2B_MARKETPLACE',
    'BLOG',
    'NEWS',
    'GUEST_POST',
    'SUPPLIER',
    'PARTNER',
    'ASSOCIATION',
    'COMMUNITY',
    'SOCIAL_PROFILE',
    'LOCAL_CITATION',
    'RESOURCE_PAGE'
);


--
-- Name: BacklinkStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BacklinkStatus" AS ENUM (
    'DISCOVERED',
    'REVIEWING',
    'APPROVED',
    'CONTACTED',
    'SUBMITTED',
    'LIVE',
    'REJECTED',
    'REMOVED'
);


--
-- Name: ContentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ContentStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED'
);


--
-- Name: DailyContentPlanStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DailyContentPlanStatus" AS ENUM (
    'PLANNED',
    'GENERATING',
    'DRAFT',
    'PUBLISHED',
    'FAILED'
);


--
-- Name: DailyContentRunStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DailyContentRunStatus" AS ENUM (
    'RUNNING',
    'COMPLETED',
    'PARTIAL',
    'FAILED'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED'
);


--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductType" AS ENUM (
    'TIRE',
    'RIM',
    'SERVICE'
);


--
-- Name: RimType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RimType" AS ENUM (
    'LIP',
    'CLICK',
    'STANDARD'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN_MANAGER',
    'STOREKEEPER'
);


--
-- Name: SeoAuditScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SeoAuditScope" AS ENUM (
    'SITE',
    'PRODUCT',
    'POST'
);


--
-- Name: SeoAuditStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SeoAuditStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'FAILED'
);


--
-- Name: SeoKeywordIntent; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SeoKeywordIntent" AS ENUM (
    'INFORMATIONAL',
    'NAVIGATIONAL',
    'COMMERCIAL',
    'TRANSACTIONAL'
);


--
-- Name: SeoKeywordStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SeoKeywordStatus" AS ENUM (
    'PLANNED',
    'ACTIVE',
    'PAUSED',
    'ARCHIVED'
);


--
-- Name: SeoKeywordType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SeoKeywordType" AS ENUM (
    'PRIMARY',
    'SECONDARY',
    'SUPPORTING',
    'BRANDED',
    'LOCAL'
);


--
-- Name: TireCondition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TireCondition" AS ENUM (
    'NEW',
    'USED'
);


--
-- Name: TireType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TireType" AS ENUM (
    'SOLID',
    'PNEUMATIC',
    'NON_MARKING'
);


--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TransactionType" AS ENUM (
    'IMPORT',
    'EXPORT',
    'ASSEMBLY_OUT',
    'ASSEMBLY_IN'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AboutPage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AboutPage" (
    id text NOT NULL,
    title text NOT NULL,
    summary text NOT NULL,
    content text NOT NULL,
    "imageUrl" text,
    "isPublished" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AiGeneration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiGeneration" (
    id text NOT NULL,
    type public."AiGenerationType" NOT NULL,
    prompt text NOT NULL,
    input jsonb NOT NULL,
    output jsonb,
    status public."AiGenerationStatus" DEFAULT 'PENDING'::public."AiGenerationStatus" NOT NULL,
    provider text,
    model text,
    error text,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AssemblyLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AssemblyLog" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "wheelRimId" text NOT NULL,
    quantity integer NOT NULL,
    "pressingFee" double precision DEFAULT 0 NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Backlink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Backlink" (
    id text NOT NULL,
    "opportunityId" text NOT NULL,
    "sourceUrl" text NOT NULL,
    "sourceDomain" text NOT NULL,
    "targetUrl" text NOT NULL,
    "anchorText" text,
    rel text,
    "firstSeenAt" timestamp(3) without time zone,
    "lastCheckedAt" timestamp(3) without time zone,
    "isLive" boolean DEFAULT false NOT NULL,
    "verificationNote" text
);


--
-- Name: BacklinkOpportunity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BacklinkOpportunity" (
    id text NOT NULL,
    domain text NOT NULL,
    url text NOT NULL,
    name text NOT NULL,
    type public."BacklinkOpportunityType" NOT NULL,
    "relevanceScore" integer,
    "authorityScore" integer,
    "spamRiskScore" integer,
    "supportsRegistration" boolean,
    "supportsPosting" boolean,
    "supportsProfileLink" boolean,
    "supportsGuestPost" boolean,
    "contactUrl" text,
    "contactEmail" text,
    status public."BacklinkStatus" DEFAULT 'DISCOVERED'::public."BacklinkStatus" NOT NULL,
    notes text,
    evidence text NOT NULL,
    "evidenceUrl" text NOT NULL,
    details jsonb NOT NULL,
    "suggestedTargetUrl" text NOT NULL,
    "suggestedAnchorTexts" text[],
    "suggestedApproach" text NOT NULL,
    risk text DEFAULT 'UNKNOWN'::text NOT NULL,
    "requiresManualReview" boolean DEFAULT true NOT NULL,
    outreach jsonb,
    "discoveredAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastCheckedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignPost" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "postId" text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "plannedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name text NOT NULL,
    "tireSize" text NOT NULL,
    brand text NOT NULL,
    "tireType" public."TireType" NOT NULL,
    "rimType" public."RimType" NOT NULL,
    origin text NOT NULL,
    condition public."TireCondition" NOT NULL,
    specifications text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    company text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'RETAIL'::text NOT NULL
);


--
-- Name: ContentCampaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ContentCampaign" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    goal text,
    status public."ContentStatus" DEFAULT 'DRAFT'::public."ContentStatus" NOT NULL,
    "startsAt" timestamp(3) without time zone,
    "endsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: DailyContentPlan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DailyContentPlan" (
    id text NOT NULL,
    "runId" text NOT NULL,
    slot integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    topic text NOT NULL,
    "primaryKeyword" text NOT NULL,
    "secondaryKeywords" text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "searchIntent" text NOT NULL,
    cluster text NOT NULL,
    "targetProductId" text,
    "postId" text,
    status public."DailyContentPlanStatus" DEFAULT 'PLANNED'::public."DailyContentPlanStatus" NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "internalLinks" jsonb,
    quality jsonb,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: DailyContentRun; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DailyContentRun" (
    id text NOT NULL,
    "runDate" text NOT NULL,
    status public."DailyContentRunStatus" DEFAULT 'RUNNING'::public."DailyContentRunStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    error text,
    summary jsonb
);


--
-- Name: FavouriteProduct; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FavouriteProduct" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: InternalLinkSuggestion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InternalLinkSuggestion" (
    id text NOT NULL,
    "sourceType" text NOT NULL,
    "sourceId" text NOT NULL,
    "targetType" text NOT NULL,
    "targetId" text NOT NULL,
    "sourceUrl" text NOT NULL,
    "targetUrl" text NOT NULL,
    "anchorText" text NOT NULL,
    reason text NOT NULL,
    score integer NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: InventoryTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InventoryTransaction" (
    id text NOT NULL,
    code text NOT NULL,
    type public."TransactionType" NOT NULL,
    "partnerName" text,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "warehouseId" text NOT NULL,
    zone text NOT NULL,
    rack text NOT NULL,
    slot text NOT NULL,
    "locationCode" text NOT NULL,
    capacity integer DEFAULT 50 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


--
-- Name: Order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "totalAmount" double precision NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "stripeSessionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    code text NOT NULL
);


--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text,
    "wheelRimId" text,
    "locationId" text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL
);


--
-- Name: Post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "videoUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    slug text,
    excerpt text,
    "tableOfContents" jsonb,
    seo jsonb,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    status public."ContentStatus" DEFAULT 'PUBLISHED'::public."ContentStatus" NOT NULL,
    aliases text[] DEFAULT ARRAY[]::text[] NOT NULL
);


--
-- Name: PostComment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PostComment" (
    id text NOT NULL,
    "postId" text NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PriceMatrix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PriceMatrix" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "customerType" text NOT NULL,
    price double precision NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    type public."ProductType" DEFAULT 'TIRE'::public."ProductType" NOT NULL,
    name text NOT NULL,
    "importPrice" double precision NOT NULL,
    "sellingPrice" double precision,
    "imageUrl" text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sku text NOT NULL,
    size text,
    brand text,
    "tireType" text,
    "rimType" text,
    condition text,
    "minStock" integer DEFAULT 5 NOT NULL,
    "maxStock" integer DEFAULT 100 NOT NULL,
    slug text,
    "shortDescription" text,
    highlights jsonb,
    specifications jsonb,
    applications jsonb,
    seo jsonb,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    status public."ContentStatus" DEFAULT 'PUBLISHED'::public."ContentStatus" NOT NULL,
    aliases text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "categoryId" text
);


--
-- Name: ProductComment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductComment" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL,
    rating integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SeedHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SeedHistory" (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    "executedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SeoAudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SeoAudit" (
    id text NOT NULL,
    report jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scope public."SeoAuditScope" DEFAULT 'SITE'::public."SeoAuditScope" NOT NULL,
    status public."SeoAuditStatus" DEFAULT 'COMPLETED'::public."SeoAuditStatus" NOT NULL,
    "productId" text,
    "postId" text,
    "subjectUrl" text,
    "primaryKeyword" text,
    "metaTitle" text,
    "metaDescription" text,
    canonical text,
    "imageAlt" text,
    "headingStructure" jsonb,
    "internalLinks" jsonb,
    issues jsonb,
    score integer
);


--
-- Name: SeoKeyword; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SeoKeyword" (
    id text NOT NULL,
    keyword text NOT NULL,
    type public."SeoKeywordType" DEFAULT 'PRIMARY'::public."SeoKeywordType" NOT NULL,
    intent public."SeoKeywordIntent" DEFAULT 'INFORMATIONAL'::public."SeoKeywordIntent" NOT NULL,
    priority integer DEFAULT 3 NOT NULL,
    cluster text,
    "targetUrl" text NOT NULL,
    "productId" text,
    "postId" text,
    status public."SeoKeywordStatus" DEFAULT 'PLANNED'::public."SeoKeywordStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Stock" (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "locationId" text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: StockLocation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StockLocation" (
    id text NOT NULL,
    "locationId" text NOT NULL,
    "productId" text,
    "wheelRimId" text,
    quantity integer DEFAULT 0 NOT NULL
);


--
-- Name: StoreInfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StoreInfo" (
    id text NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    phone text NOT NULL,
    email text,
    website text,
    "taxCode" text,
    "logoUrl" text,
    "facebookUrl" text,
    "businessHours" text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Supplier" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    address text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    company text
);


--
-- Name: TransactionDetail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TransactionDetail" (
    id text NOT NULL,
    "txId" text NOT NULL,
    "productId" text,
    "wheelRimId" text,
    "locationId" text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public."Role" DEFAULT 'STOREKEEPER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Warehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Warehouse" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    address text
);


--
-- Name: WheelRim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WheelRim" (
    id text NOT NULL,
    sku text NOT NULL,
    size text NOT NULL,
    "boltHoles" integer NOT NULL,
    "compatibleModels" text,
    brand text,
    "importPrice" double precision NOT NULL,
    "sellingPrice" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: AboutPage AboutPage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AboutPage"
    ADD CONSTRAINT "AboutPage_pkey" PRIMARY KEY (id);


--
-- Name: AiGeneration AiGeneration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiGeneration"
    ADD CONSTRAINT "AiGeneration_pkey" PRIMARY KEY (id);


--
-- Name: AssemblyLog AssemblyLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AssemblyLog"
    ADD CONSTRAINT "AssemblyLog_pkey" PRIMARY KEY (id);


--
-- Name: BacklinkOpportunity BacklinkOpportunity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BacklinkOpportunity"
    ADD CONSTRAINT "BacklinkOpportunity_pkey" PRIMARY KEY (id);


--
-- Name: Backlink Backlink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Backlink"
    ADD CONSTRAINT "Backlink_pkey" PRIMARY KEY (id);


--
-- Name: CampaignPost CampaignPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPost"
    ADD CONSTRAINT "CampaignPost_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: ContentCampaign ContentCampaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ContentCampaign"
    ADD CONSTRAINT "ContentCampaign_pkey" PRIMARY KEY (id);


--
-- Name: DailyContentPlan DailyContentPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyContentPlan"
    ADD CONSTRAINT "DailyContentPlan_pkey" PRIMARY KEY (id);


--
-- Name: DailyContentRun DailyContentRun_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyContentRun"
    ADD CONSTRAINT "DailyContentRun_pkey" PRIMARY KEY (id);


--
-- Name: FavouriteProduct FavouriteProduct_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FavouriteProduct"
    ADD CONSTRAINT "FavouriteProduct_pkey" PRIMARY KEY (id);


--
-- Name: InternalLinkSuggestion InternalLinkSuggestion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InternalLinkSuggestion"
    ADD CONSTRAINT "InternalLinkSuggestion_pkey" PRIMARY KEY (id);


--
-- Name: InventoryTransaction InventoryTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_locationCode_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_locationCode_key" UNIQUE ("locationCode");


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PostComment PostComment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: PriceMatrix PriceMatrix_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PriceMatrix"
    ADD CONSTRAINT "PriceMatrix_pkey" PRIMARY KEY (id);


--
-- Name: ProductComment ProductComment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductComment"
    ADD CONSTRAINT "ProductComment_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: SeedHistory SeedHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeedHistory"
    ADD CONSTRAINT "SeedHistory_pkey" PRIMARY KEY (id);


--
-- Name: SeoAudit SeoAudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoAudit"
    ADD CONSTRAINT "SeoAudit_pkey" PRIMARY KEY (id);


--
-- Name: SeoKeyword SeoKeyword_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoKeyword"
    ADD CONSTRAINT "SeoKeyword_pkey" PRIMARY KEY (id);


--
-- Name: StockLocation StockLocation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockLocation"
    ADD CONSTRAINT "StockLocation_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (id);


--
-- Name: StoreInfo StoreInfo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreInfo"
    ADD CONSTRAINT "StoreInfo_pkey" PRIMARY KEY (id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (id);


--
-- Name: TransactionDetail TransactionDetail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransactionDetail"
    ADD CONSTRAINT "TransactionDetail_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY (id);


--
-- Name: WheelRim WheelRim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WheelRim"
    ADD CONSTRAINT "WheelRim_pkey" PRIMARY KEY (id);


--
-- Name: WheelRim WheelRim_sku_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WheelRim"
    ADD CONSTRAINT "WheelRim_sku_key" UNIQUE (sku);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: BacklinkOpportunity_domain_url_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BacklinkOpportunity_domain_url_key" ON public."BacklinkOpportunity" USING btree (domain, url);


--
-- Name: BacklinkOpportunity_status_relevanceScore_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BacklinkOpportunity_status_relevanceScore_idx" ON public."BacklinkOpportunity" USING btree (status, "relevanceScore");


--
-- Name: Backlink_sourceUrl_targetUrl_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Backlink_sourceUrl_targetUrl_key" ON public."Backlink" USING btree ("sourceUrl", "targetUrl");


--
-- Name: CampaignPost_campaignId_postId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "CampaignPost_campaignId_postId_key" ON public."CampaignPost" USING btree ("campaignId", "postId");


--
-- Name: CampaignPost_campaignId_sortOrder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignPost_campaignId_sortOrder_idx" ON public."CampaignPost" USING btree ("campaignId", "sortOrder");


--
-- Name: CampaignPost_postId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignPost_postId_idx" ON public."CampaignPost" USING btree ("postId");


--
-- Name: Client_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Client_email_key" ON public."Client" USING btree (email);


--
-- Name: ContentCampaign_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ContentCampaign_slug_key" ON public."ContentCampaign" USING btree (slug);


--
-- Name: ContentCampaign_status_startsAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ContentCampaign_status_startsAt_idx" ON public."ContentCampaign" USING btree (status, "startsAt");


--
-- Name: DailyContentPlan_cluster_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DailyContentPlan_cluster_createdAt_idx" ON public."DailyContentPlan" USING btree (cluster, "createdAt");


--
-- Name: DailyContentPlan_postId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyContentPlan_postId_key" ON public."DailyContentPlan" USING btree ("postId");


--
-- Name: DailyContentPlan_runId_slot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyContentPlan_runId_slot_key" ON public."DailyContentPlan" USING btree ("runId", slot);


--
-- Name: DailyContentPlan_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyContentPlan_slug_key" ON public."DailyContentPlan" USING btree (slug);


--
-- Name: DailyContentPlan_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DailyContentPlan_status_createdAt_idx" ON public."DailyContentPlan" USING btree (status, "createdAt");


--
-- Name: DailyContentRun_runDate_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyContentRun_runDate_key" ON public."DailyContentRun" USING btree ("runDate");


--
-- Name: FavouriteProduct_productId_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "FavouriteProduct_productId_userId_key" ON public."FavouriteProduct" USING btree ("productId", "userId");


--
-- Name: InternalLinkSuggestion_sourceType_sourceId_targetType_targe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "InternalLinkSuggestion_sourceType_sourceId_targetType_targe_key" ON public."InternalLinkSuggestion" USING btree ("sourceType", "sourceId", "targetType", "targetId");


--
-- Name: InventoryTransaction_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "InventoryTransaction_code_key" ON public."InventoryTransaction" USING btree (code);


--
-- Name: Order_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Order_code_key" ON public."Order" USING btree (code);


--
-- Name: Order_stripeSessionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Order_stripeSessionId_key" ON public."Order" USING btree ("stripeSessionId");


--
-- Name: Post_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Post_slug_key" ON public."Post" USING btree (slug);


--
-- Name: PriceMatrix_productId_customerType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PriceMatrix_productId_customerType_key" ON public."PriceMatrix" USING btree ("productId", "customerType");


--
-- Name: Product_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_categoryId_idx" ON public."Product" USING btree ("categoryId");


--
-- Name: Product_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_sku_key" ON public."Product" USING btree (sku);


--
-- Name: Product_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_slug_key" ON public."Product" USING btree (slug);


--
-- Name: SeedHistory_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SeedHistory_key_key" ON public."SeedHistory" USING btree (key);


--
-- Name: SeoAudit_postId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoAudit_postId_createdAt_idx" ON public."SeoAudit" USING btree ("postId", "createdAt");


--
-- Name: SeoAudit_productId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoAudit_productId_createdAt_idx" ON public."SeoAudit" USING btree ("productId", "createdAt");


--
-- Name: SeoAudit_scope_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoAudit_scope_createdAt_idx" ON public."SeoAudit" USING btree (scope, "createdAt");


--
-- Name: SeoKeyword_cluster_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoKeyword_cluster_status_idx" ON public."SeoKeyword" USING btree (cluster, status);


--
-- Name: SeoKeyword_keyword_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SeoKeyword_keyword_key" ON public."SeoKeyword" USING btree (keyword);


--
-- Name: SeoKeyword_postId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoKeyword_postId_idx" ON public."SeoKeyword" USING btree ("postId");


--
-- Name: SeoKeyword_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoKeyword_productId_idx" ON public."SeoKeyword" USING btree ("productId");


--
-- Name: SeoKeyword_status_priority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeoKeyword_status_priority_idx" ON public."SeoKeyword" USING btree (status, priority);


--
-- Name: StockLocation_locationId_productId_wheelRimId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "StockLocation_locationId_productId_wheelRimId_key" ON public."StockLocation" USING btree ("locationId", "productId", "wheelRimId");


--
-- Name: Supplier_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Supplier_email_key" ON public."Supplier" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Warehouse_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Warehouse_code_key" ON public."Warehouse" USING btree (code);


--
-- Name: AssemblyLog AssemblyLog_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AssemblyLog"
    ADD CONSTRAINT "AssemblyLog_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AssemblyLog AssemblyLog_wheelRimId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AssemblyLog"
    ADD CONSTRAINT "AssemblyLog_wheelRimId_fkey" FOREIGN KEY ("wheelRimId") REFERENCES public."WheelRim"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Backlink Backlink_opportunityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Backlink"
    ADD CONSTRAINT "Backlink_opportunityId_fkey" FOREIGN KEY ("opportunityId") REFERENCES public."BacklinkOpportunity"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignPost CampaignPost_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPost"
    ADD CONSTRAINT "CampaignPost_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."ContentCampaign"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignPost CampaignPost_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPost"
    ADD CONSTRAINT "CampaignPost_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DailyContentPlan DailyContentPlan_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyContentPlan"
    ADD CONSTRAINT "DailyContentPlan_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DailyContentPlan DailyContentPlan_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyContentPlan"
    ADD CONSTRAINT "DailyContentPlan_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."DailyContentRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DailyContentPlan DailyContentPlan_targetProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyContentPlan"
    ADD CONSTRAINT "DailyContentPlan_targetProductId_fkey" FOREIGN KEY ("targetProductId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FavouriteProduct FavouriteProduct_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FavouriteProduct"
    ADD CONSTRAINT "FavouriteProduct_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FavouriteProduct FavouriteProduct_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FavouriteProduct"
    ADD CONSTRAINT "FavouriteProduct_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_wheelRimId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_wheelRimId_fkey" FOREIGN KEY ("wheelRimId") REFERENCES public."WheelRim"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PostComment PostComment_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PostComment PostComment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PriceMatrix PriceMatrix_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PriceMatrix"
    ADD CONSTRAINT "PriceMatrix_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductComment ProductComment_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductComment"
    ADD CONSTRAINT "ProductComment_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductComment ProductComment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductComment"
    ADD CONSTRAINT "ProductComment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeoAudit SeoAudit_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoAudit"
    ADD CONSTRAINT "SeoAudit_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeoAudit SeoAudit_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoAudit"
    ADD CONSTRAINT "SeoAudit_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeoKeyword SeoKeyword_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoKeyword"
    ADD CONSTRAINT "SeoKeyword_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeoKeyword SeoKeyword_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeoKeyword"
    ADD CONSTRAINT "SeoKeyword_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StockLocation StockLocation_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockLocation"
    ADD CONSTRAINT "StockLocation_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockLocation StockLocation_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockLocation"
    ADD CONSTRAINT "StockLocation_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StockLocation StockLocation_wheelRimId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockLocation"
    ADD CONSTRAINT "StockLocation_wheelRimId_fkey" FOREIGN KEY ("wheelRimId") REFERENCES public."WheelRim"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Stock Stock_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Stock Stock_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TransactionDetail TransactionDetail_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransactionDetail"
    ADD CONSTRAINT "TransactionDetail_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TransactionDetail TransactionDetail_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransactionDetail"
    ADD CONSTRAINT "TransactionDetail_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TransactionDetail TransactionDetail_txId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransactionDetail"
    ADD CONSTRAINT "TransactionDetail_txId_fkey" FOREIGN KEY ("txId") REFERENCES public."InventoryTransaction"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TransactionDetail TransactionDetail_wheelRimId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TransactionDetail"
    ADD CONSTRAINT "TransactionDetail_wheelRimId_fkey" FOREIGN KEY ("wheelRimId") REFERENCES public."WheelRim"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 7cfuFiRArzshAMdgoCTSmzJkSkyexOHaq82ZqnpbTYl8g3Bb1WfiYy0mKIv7UcB

